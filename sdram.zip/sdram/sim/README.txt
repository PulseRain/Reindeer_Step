To run the sim

1. do build_lib.do

2. do build_sdram.do

3. do run_sim.do

